import sys
import os
import yaml
import coloredlogs
import traceback


def main():
    print("检查环境变量 POETRY_HOME：", os.getenv("POETRY_HOME"))


if __name__ == '__main__':
    sys.exit(main())
