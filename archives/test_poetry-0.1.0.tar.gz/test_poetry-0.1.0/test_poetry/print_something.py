def do_something():
    print('成功执行从指定路径安装的依赖')
